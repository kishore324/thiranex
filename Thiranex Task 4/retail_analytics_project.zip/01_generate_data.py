"""Generate a realistic, deliberately messy e-commerce transactions dataset.

Schema mirrors the well-known "Online Retail" dataset:
InvoiceNo, StockCode, Description, Quantity, InvoiceDate, UnitPrice, CustomerID, Country

Messiness injected on purpose so the cleaning step is meaningful:
 - ~20% of rows without CustomerID (guest checkouts)
 - cancelled invoices (InvoiceNo starts with 'C', negative quantity)
 - exact duplicate rows
 - zero / negative prices (adjustments)
 - inconsistent description casing / whitespace
"""
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)

N_CUSTOMERS = 4000
START, END = pd.Timestamp("2025-10-01"), pd.Timestamp("2026-09-30")

# ---- product catalogue ------------------------------------------------------
categories = {
    "Home Decor":   (["Wall Clock", "Photo Frame", "Scented Candle", "Cushion Cover", "Table Lamp", "Wall Art"], 4, 25),
    "Kitchen":      (["Mug Set", "Cutlery Pack", "Storage Jar", "Chopping Board", "Tea Towel", "Lunch Box"], 2, 18),
    "Stationery":   (["Notebook", "Pen Pack", "Planner", "Sticker Sheet", "Greeting Card", "Gift Wrap"], 1, 8),
    "Toys & Games": (["Puzzle", "Board Game", "Plush Toy", "Building Blocks", "Card Game"], 3, 30),
    "Seasonal":     (["Christmas Ornament", "Fairy Lights", "Advent Calendar", "Gift Tin", "Festive Bunting"], 2, 22),
}
products = []
pid = 10000
for cat, (names, lo, hi) in categories.items():
    for n in names:
        for variant in ["Red", "Blue", "Vintage", "Floral", "Classic"]:
            pid += 1
            products.append((str(pid), f"{variant} {n}", cat, round(float(rng.uniform(lo, hi)), 2)))
prod = pd.DataFrame(products, columns=["StockCode", "Description", "Category", "BasePrice"])
# popularity weights (long tail)
prod["w"] = rng.pareto(1.6, len(prod)) + 0.2
prod["w"] /= prod["w"].sum()

countries = ["United Kingdom", "Germany", "France", "India", "Netherlands", "Spain", "Australia", "Ireland"]
c_prob = [0.70, 0.07, 0.06, 0.05, 0.04, 0.03, 0.03, 0.02]

# ---- customers: latent behaviour types -------------------------------------
cust = pd.DataFrame({
    "CustomerID": np.arange(12000, 12000 + N_CUSTOMERS),
    "Country": rng.choice(countries, N_CUSTOMERS, p=c_prob),
    "orders_per_year": np.clip(rng.gamma(1.6, 4.5, N_CUSTOMERS), 0.5, 40),
    "basket_scale": rng.lognormal(0, 0.5, N_CUSTOMERS),
    "join": START + pd.to_timedelta(rng.integers(0, 300, N_CUSTOMERS), unit="D"),
    "churn_after": START + pd.to_timedelta(rng.integers(60, 420, N_CUSTOMERS), unit="D"),
})
# ~35% of customers eventually churn (stop buying)
cust.loc[rng.random(N_CUSTOMERS) > 0.35, "churn_after"] = END + pd.Timedelta(days=1)

def seasonal_weight(d):
    m = d.month
    w = 1.0
    if m in (11, 12): w = 2.2          # holiday peak
    elif m in (1, 2): w = 0.7
    return w * (1.25 if d.dayofweek in (3, 4) else 1.0)

all_days = pd.date_range(START, END)
day_w = np.array([seasonal_weight(d) for d in all_days])

rows, inv = [], 500000
for _, c in cust.iterrows():
    active_days = all_days[(all_days >= c["join"]) & (all_days <= c["churn_after"])]
    if len(active_days) == 0:
        continue
    n_orders = rng.poisson(c["orders_per_year"] * len(active_days) / 365)
    if n_orders == 0:
        continue
    w = day_w[(all_days >= c["join"]) & (all_days <= c["churn_after"])]
    days = rng.choice(active_days, n_orders, p=w / w.sum())
    for d in days:
        inv += 1
        ts = pd.Timestamp(d) + pd.Timedelta(hours=int(rng.integers(8, 21)), minutes=int(rng.integers(0, 60)))
        n_items = max(1, int(rng.poisson(3 * c["basket_scale"])))
        picks = rng.choice(len(prod), min(n_items, 12), replace=False, p=prod["w"])
        cancelled = rng.random() < 0.025
        for p in picks:
            qty = int(np.clip(rng.geometric(0.22) * (1 + (rng.random() < 0.05) * 10), 1, 200))
            price = round(prod.BasePrice[p] * rng.uniform(0.95, 1.05), 2)
            rows.append([("C" if cancelled else "") + str(inv), prod.StockCode[p], prod.Description[p],
                         -qty if cancelled else qty, ts, price, c["CustomerID"], c["Country"]])

df = pd.DataFrame(rows, columns=["InvoiceNo", "StockCode", "Description", "Quantity",
                                 "InvoiceDate", "UnitPrice", "CustomerID", "Country"])

# ---- inject mess ------------------------------------------------------------
guest = rng.random(len(df)) < 0.20
df.loc[guest, "CustomerID"] = np.nan
bad = rng.choice(df.index, 400, replace=False)
df.loc[bad, "UnitPrice"] = rng.choice([0.0, -1.0], 400)
df.loc[rng.choice(df.index, 1500, replace=False), "Description"] = None  # missing descriptions
mask = rng.random(len(df)) < 0.1
df.loc[mask, "Description"] = df.loc[mask, "Description"].map(lambda s: f"  {s.upper()} " if isinstance(s, str) else s)
dups = df.sample(900, random_state=1)
df = pd.concat([df, dups]).sample(frac=1, random_state=7).reset_index(drop=True)

df.to_csv("data/raw_transactions.csv", index=False)
print(f"Generated {len(df):,} rows, {df.CustomerID.nunique():,} customers -> data/raw_transactions.csv")

"""End-to-end retail analytics: clean -> EDA -> RFM segmentation -> predict repeat purchase.

Run:  python 02_analysis.py
Outputs: data/clean_transactions.csv, data/rfm_segments.csv, charts/*.png, results.json
"""
import json
import warnings

import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (RocCurveDisplay, classification_report, roc_auc_score)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

warnings.filterwarnings("ignore")
sns.set_theme(style="whitegrid", context="notebook")
BLUE, ORANGE, GREY = "#2a6fdb", "#e8833a", "#8a8f98"
results = {}


def save(fig, name):
    fig.tight_layout()
    fig.savefig(f"charts/{name}.png", dpi=150)
    plt.close(fig)


# =============================================================== 1. LOAD
raw = pd.read_csv("data/raw_transactions.csv", parse_dates=["InvoiceDate"], dtype={"InvoiceNo": str, "StockCode": str})
results["raw_rows"] = len(raw)
print("RAW shape:", raw.shape)
print(raw.isna().sum())

# =============================================================== 2. CLEAN
df = raw.copy()
issues = {}
issues["exact_duplicates"] = int(df.duplicated().sum())
df = df.drop_duplicates()

df["Description"] = df["Description"].str.strip().str.title()
# recover missing descriptions from the StockCode lookup
lookup = df.dropna(subset=["Description"]).groupby("StockCode")["Description"].first()
issues["missing_description_fixed"] = int(df["Description"].isna().sum())
df["Description"] = df["Description"].fillna(df["StockCode"].map(lookup))

df["IsCancelled"] = df["InvoiceNo"].str.startswith("C")
issues["cancelled_lines"] = int(df["IsCancelled"].sum())
issues["bad_price_lines"] = int((df["UnitPrice"] <= 0).sum())
issues["guest_lines_no_customer"] = int(df["CustomerID"].isna().sum())

sales = df[(~df["IsCancelled"]) & (df["UnitPrice"] > 0) & (df["Quantity"] > 0)].copy()
sales["Revenue"] = sales["Quantity"] * sales["UnitPrice"]
results["cleaning"] = issues
results["clean_rows"] = len(sales)
print("Cleaning summary:", issues, "| rows kept:", len(sales))

# feature engineering
sales["Month"] = sales["InvoiceDate"].dt.to_period("M").dt.to_timestamp()
sales["DayOfWeek"] = sales["InvoiceDate"].dt.day_name()
sales["Hour"] = sales["InvoiceDate"].dt.hour
cat_map = {"Mug": "Kitchen", "Cutlery": "Kitchen", "Jar": "Kitchen", "Chopping": "Kitchen", "Towel": "Kitchen", "Lunch": "Kitchen",
           "Clock": "Home Decor", "Frame": "Home Decor", "Candle": "Home Decor", "Cushion": "Home Decor", "Lamp": "Home Decor", "Wall Art": "Home Decor",
           "Notebook": "Stationery", "Pen": "Stationery", "Planner": "Stationery", "Sticker": "Stationery", "Card": "Stationery", "Gift Wrap": "Stationery",
           "Puzzle": "Toys & Games", "Board": "Toys & Games", "Plush": "Toys & Games", "Blocks": "Toys & Games", "Card Game": "Toys & Games"}


def categorise(desc):
    if "Card Game" in desc:
        return "Toys & Games"
    for k, v in cat_map.items():
        if k in desc:
            return v
    return "Seasonal"


sales["Category"] = sales["Description"].map(categorise)
sales.to_csv("data/clean_transactions.csv", index=False)

known = sales.dropna(subset=["CustomerID"]).copy()
known["CustomerID"] = known["CustomerID"].astype(int)

# =============================================================== 3. EDA
total_rev = sales["Revenue"].sum()
orders = sales["InvoiceNo"].nunique()
results["kpis"] = {
    "total_revenue": round(total_rev, 2),
    "orders": int(orders),
    "customers": int(known["CustomerID"].nunique()),
    "avg_order_value": round(total_rev / orders, 2),
    "guest_revenue_share": round(sales[sales.CustomerID.isna()].Revenue.sum() / total_rev, 3),
}

# 3a monthly revenue + orders
m = sales.groupby("Month").agg(Revenue=("Revenue", "sum"), Orders=("InvoiceNo", "nunique"))
fig, ax = plt.subplots(figsize=(9, 4.2))
ax.bar(m.index, m["Revenue"], width=22, color=BLUE)
dec, jan = m.loc["2025-12-01", "Revenue"], m.loc["2026-01-01", "Revenue"]
results["dec_vs_jan_revenue_ratio"] = round(float(dec / jan), 2)
ax.set_title("Revenue grows with the customer base; December spikes above the trend", loc="left", fontweight="bold", fontsize=11)
ax.set_ylabel("Revenue"); ax.yaxis.set_major_formatter(mtick.StrMethodFormatter("{x:,.0f}"))
ax.set_xlabel("")
save(fig, "01_monthly_revenue")
results["peak_month"] = str(m["Revenue"].idxmax().strftime("%b %Y"))
results["peak_month_revenue_vs_median"] = round(m["Revenue"].max() / m["Revenue"].median(), 2)

# 3b category revenue
cat = sales.groupby("Category")["Revenue"].sum().sort_values()
fig, ax = plt.subplots(figsize=(7, 3.8))
ax.barh(cat.index, cat.values, color=BLUE)
for i, v in enumerate(cat.values):
    ax.text(v, i, f"  {v / total_rev:.0%}", va="center")
ax.set_title("Revenue by category", loc="left", fontweight="bold"); ax.xaxis.set_major_formatter(mtick.StrMethodFormatter("{x:,.0f}"))
save(fig, "02_category_revenue")
results["top_category"] = {"name": cat.index[-1], "share": round(cat.iloc[-1] / total_rev, 3)}

# 3c top products
top = sales.groupby("Description")["Revenue"].sum().nlargest(10).sort_values()
fig, ax = plt.subplots(figsize=(7.5, 4.5))
ax.barh(top.index, top.values, color=BLUE)
ax.set_title("Top 10 products by revenue", loc="left", fontweight="bold"); ax.xaxis.set_major_formatter(mtick.StrMethodFormatter("{x:,.0f}"))
save(fig, "03_top_products")
prod_rev = sales.groupby("Description")["Revenue"].sum().sort_values(ascending=False)
results["top20pct_products_revenue_share"] = round(prod_rev.head(int(len(prod_rev) * 0.2)).sum() / total_rev, 3)

# 3d country
ctry = sales.groupby("Country")["Revenue"].sum().sort_values()
fig, ax = plt.subplots(figsize=(7, 4))
ax.barh(ctry.index, ctry.values, color=[ORANGE if c == "United Kingdom" else BLUE for c in ctry.index])
ax.set_title("Revenue by country", loc="left", fontweight="bold"); ax.xaxis.set_major_formatter(mtick.StrMethodFormatter("{x:,.0f}"))
save(fig, "04_country_revenue")
results["uk_share"] = round(ctry["United Kingdom"] / total_rev, 3)

# 3e when do people buy: weekday x hour
order_times = sales.drop_duplicates("InvoiceNo")
order_times["DayOfWeek"] = pd.Categorical(order_times["DayOfWeek"], ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"], ordered=True)
heat = order_times.pivot_table(index="DayOfWeek", columns="Hour", values="InvoiceNo", aggfunc="count", observed=False)
fig, ax = plt.subplots(figsize=(9, 3.8))
sns.heatmap(heat, cmap="Blues", ax=ax, cbar_kws={"label": "Orders"})
ax.set_title("When customers order (weekday x hour)", loc="left", fontweight="bold"); ax.set_xlabel("Hour of day"); ax.set_ylabel("")
save(fig, "05_order_heatmap")
dow = order_times.groupby("DayOfWeek", observed=False).size()
results["busiest_day"] = str(dow.idxmax())

# 3f cohort retention
first = known.groupby("CustomerID")["InvoiceDate"].min().dt.to_period("M").rename("Cohort")
k2 = known.join(first, on="CustomerID")
k2["Period"] = k2["InvoiceDate"].dt.to_period("M")
k2["Age"] = (k2["Period"] - k2["Cohort"]).apply(lambda x: x.n)
coh = k2.groupby(["Cohort", "Age"])["CustomerID"].nunique().unstack()
ret = coh.divide(coh[0], axis=0).iloc[:9, :9]
fig, ax = plt.subplots(figsize=(8, 4.5))
sns.heatmap(ret, annot=True, fmt=".0%", cmap="Blues", ax=ax, cbar=False, vmin=0, vmax=1)
ax.set_title("Cohort retention: share of customers still buying", loc="left", fontweight="bold")
ax.set_xlabel("Months since first purchase"); ax.set_ylabel("First-purchase month")
ax.set_yticklabels([str(c) for c in ret.index], rotation=0)
save(fig, "06_cohort_retention")

# =============================================================== 4. RFM
snapshot = known["InvoiceDate"].max().normalize() + pd.Timedelta(days=1)
rfm = known.groupby("CustomerID").agg(
    Recency=("InvoiceDate", lambda x: (snapshot - x.max()).days),
    Frequency=("InvoiceNo", "nunique"),
    Monetary=("Revenue", "sum"),
)
rfm["R"] = pd.qcut(rfm["Recency"].rank(method="first"), 5, labels=[5, 4, 3, 2, 1]).astype(int)
rfm["F"] = pd.qcut(rfm["Frequency"].rank(method="first"), 5, labels=[1, 2, 3, 4, 5]).astype(int)
rfm["M"] = pd.qcut(rfm["Monetary"].rank(method="first"), 5, labels=[1, 2, 3, 4, 5]).astype(int)


def segment(r):
    if r.R >= 4 and r.F >= 4: return "Champions"
    if r.R >= 3 and r.F >= 3: return "Loyal"
    if r.R >= 4 and r.F <= 2: return "New / Promising"
    if r.R <= 2 and r.F >= 4: return "At Risk (high value)"
    if r.R <= 2 and r.F >= 2: return "Needs Attention"
    return "Lost / Hibernating"


rfm["Segment"] = rfm.apply(segment, axis=1)
rfm.to_csv("data/rfm_segments.csv")
seg = rfm.groupby("Segment").agg(Customers=("Monetary", "size"), Revenue=("Monetary", "sum"), AvgRecency=("Recency", "mean"),
                                 AvgFrequency=("Frequency", "mean"), AvgSpend=("Monetary", "mean")).sort_values("Revenue", ascending=False)
seg["CustomerShare"] = seg["Customers"] / seg["Customers"].sum()
seg["RevenueShare"] = seg["Revenue"] / seg["Revenue"].sum()
print(seg.round(2))
results["rfm_segments"] = seg.round(3).reset_index().to_dict(orient="records")

fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
order = seg.index.tolist()
sns.barplot(x=seg["CustomerShare"], y=order, ax=axes[0], color=GREY)
axes[0].set_title("Share of customers", loc="left", fontweight="bold"); axes[0].xaxis.set_major_formatter(mtick.PercentFormatter(1.0)); axes[0].set_xlabel("")
sns.barplot(x=seg["RevenueShare"], y=order, ax=axes[1], color=BLUE)
axes[1].set_title("Share of revenue", loc="left", fontweight="bold"); axes[1].xaxis.set_major_formatter(mtick.PercentFormatter(1.0)); axes[1].set_xlabel(""); axes[1].set_yticklabels([])
save(fig, "07_rfm_segments")

top20 = rfm["Monetary"].sort_values(ascending=False).head(int(len(rfm) * 0.2)).sum() / rfm["Monetary"].sum()
results["top20pct_customers_revenue_share"] = round(float(top20), 3)
results["repeat_customer_rate"] = round(float((rfm["Frequency"] > 1).mean()), 3)

# =============================================================== 5. PREDICTION
# Question: will a customer who bought before the cutoff buy again in the following 90 days?
# Features only use data BEFORE the cutoff (no leakage).
end = known["InvoiceDate"].max()
cutoff = (end - pd.Timedelta(days=90)).normalize()
hist = known[known["InvoiceDate"] < cutoff]
future = known[known["InvoiceDate"] >= cutoff]

feat = hist.groupby("CustomerID").agg(
    recency=("InvoiceDate", lambda x: (cutoff - x.max()).days),
    frequency=("InvoiceNo", "nunique"),
    monetary=("Revenue", "sum"),
    n_items=("Quantity", "sum"),
    n_products=("StockCode", "nunique"),
    first_purchase=("InvoiceDate", "min"),
)
feat["tenure_days"] = (cutoff - feat.pop("first_purchase")).dt.days
feat["avg_order_value"] = feat["monetary"] / feat["frequency"]
last90 = hist[hist["InvoiceDate"] >= cutoff - pd.Timedelta(days=90)].groupby("CustomerID")["InvoiceNo"].nunique()
feat["orders_last_90d"] = last90.reindex(feat.index).fillna(0)
feat["is_uk"] = (hist.groupby("CustomerID")["Country"].first().reindex(feat.index) == "United Kingdom").astype(int)
feat["target"] = feat.index.isin(future["CustomerID"].unique()).astype(int)

X, y = feat.drop(columns="target"), feat["target"]
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)

logit = make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000)).fit(Xtr, ytr)
gb = GradientBoostingClassifier(random_state=42).fit(Xtr, ytr)
auc_lr = roc_auc_score(yte, logit.predict_proba(Xte)[:, 1])
auc_gb = roc_auc_score(yte, gb.predict_proba(Xte)[:, 1])
base_rate = float(y.mean())
print(f"Base rate buys again: {base_rate:.1%} | AUC logistic {auc_lr:.3f} | AUC GB {auc_gb:.3f}")
print(classification_report(yte, gb.predict(Xte)))

results["model"] = {
    "cutoff": str(cutoff.date()), "customers_modelled": int(len(feat)), "base_rate_repurchase_90d": round(base_rate, 3),
    "auc_logistic": round(auc_lr, 3), "auc_gradient_boosting": round(auc_gb, 3),
}
imp = pd.Series(gb.feature_importances_, index=X.columns).sort_values()
results["model"]["top_features"] = imp.sort_values(ascending=False).head(4).round(3).to_dict()

fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
RocCurveDisplay.from_estimator(logit, Xte, yte, ax=axes[0], name="Logistic", curve_kwargs={"color": GREY})
RocCurveDisplay.from_estimator(gb, Xte, yte, ax=axes[0], name="Gradient boosting", curve_kwargs={"color": BLUE})
axes[0].plot([0, 1], [0, 1], "--", color="#bbb"); axes[0].set_title("Predicting a repeat purchase in the next 90 days", loc="left", fontweight="bold", fontsize=10)
axes[0].set_xlabel("False positive rate"); axes[0].set_ylabel("True positive rate"); axes[0].legend(loc="lower right", fontsize=8)
axes[1].barh(imp.index, imp.values, color=BLUE); axes[1].set_title("What drives repeat purchase", loc="left", fontweight="bold", fontsize=10)
save(fig, "08_model_performance")

# score all customers -> actionable target list (at-risk customers who are valuable)
feat["p_repurchase"] = gb.predict_proba(X)[:, 1]
feat = feat.join(rfm[["Segment"]])
feat.sort_values("p_repurchase").to_csv("data/customer_repurchase_scores.csv")

with open("results.json", "w") as f:
    json.dump(results, f, indent=2, default=str)
print(json.dumps(results, indent=2, default=str))

"""Exploratory Data Analysis with pandas: what drives diabetes progression?

Run:  python eda.py
Creates: data/diabetes.csv, figures/*.png, outputs/*.csv, outputs/results.json

Workflow (mirrors a standard EDA walkthrough):
  1. Load + inspect the data
  2. Statistical summaries (describe, skew, kurtosis, outliers, normality)
  3. Visualise distributions
  4. Compare the target across groups (with significance tests)
  5. Correlation analysis (Pearson + Spearman)
  6. Key influencing factors (standardised regression, permutation importance, VIF)
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import Patch
from scipy import stats
from sklearn.datasets import load_diabetes
from sklearn.ensemble import RandomForestRegressor
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import KFold, cross_val_score, train_test_split

BASE = Path(__file__).resolve().parent
DATA_DIR, FIG_DIR, OUT_DIR = BASE / "data", BASE / "figures", BASE / "outputs"
for d in (DATA_DIR, FIG_DIR, OUT_DIR):
    d.mkdir(exist_ok=True)

SEED = 42
TARGET = "progression"

# Palette (validated categorical slots 1-3 + neutral ink/surface tokens)
BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
SURFACE, INK, INK2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3df"

RENAME = {
    "s1": "total_chol", "s2": "ldl", "s3": "hdl",
    "s4": "tc_hdl_ratio", "s5": "log_triglycerides", "s6": "glucose",
    "target": TARGET,
}
FEATURES = ["age", "sex", "bmi", "bp", "total_chol", "ldl", "hdl",
            "tc_hdl_ratio", "log_triglycerides", "glucose"]


def style() -> None:
    plt.rcParams.update({
        "figure.facecolor": SURFACE, "axes.facecolor": SURFACE,
        "savefig.facecolor": SURFACE, "axes.edgecolor": GRID,
        "axes.labelcolor": INK2, "text.color": INK,
        "xtick.color": INK2, "ytick.color": INK2,
        "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6,
        "axes.axisbelow": True, "axes.spines.top": False,
        "axes.spines.right": False, "axes.titleweight": "bold",
        "axes.titlesize": 10.5, "axes.titlelocation": "left",
        "font.size": 9.5, "savefig.dpi": 160,
    })


def save(fig: plt.Figure, name: str) -> None:
    fig.savefig(FIG_DIR / name, bbox_inches="tight")
    plt.close(fig)


# --------------------------------------------------------------------------
# 1. Load + inspect
# --------------------------------------------------------------------------
def load() -> pd.DataFrame:
    raw = load_diabetes(as_frame=True, scaled=False)  # raw, un-standardised units
    df = raw.frame.rename(columns=RENAME)
    df.to_csv(DATA_DIR / "diabetes.csv", index=False)
    return df


def inspect(df: pd.DataFrame) -> dict:
    info = {
        "rows": int(df.shape[0]),
        "columns": int(df.shape[1]),
        "missing_values": int(df.isna().sum().sum()),
        "duplicate_rows": int(df.duplicated().sum()),
        "sex_values": sorted(df["sex"].unique().tolist()),
    }
    pd.DataFrame({"dtype": df.dtypes.astype(str),
                  "n_unique": df.nunique(),
                  "n_missing": df.isna().sum()}).to_csv(OUT_DIR / "01_schema.csv")
    return info


# --------------------------------------------------------------------------
# 2. Statistical summary
# --------------------------------------------------------------------------
def summarise(df: pd.DataFrame) -> pd.DataFrame:
    s = df.describe().T
    s["skew"] = df.skew()
    s["kurtosis"] = df.kurt()
    q1, q3 = df.quantile(0.25), df.quantile(0.75)
    iqr = q3 - q1
    s["iqr_outliers"] = ((df < q1 - 1.5 * iqr) | (df > q3 + 1.5 * iqr)).sum()
    s["shapiro_p"] = [stats.shapiro(df[c]).pvalue for c in df.columns]
    s = s.round(3)
    s.to_csv(OUT_DIR / "02_summary_statistics.csv")
    return s


# --------------------------------------------------------------------------
# 3. Distributions
# --------------------------------------------------------------------------
def plot_distributions(df: pd.DataFrame) -> None:
    cols = FEATURES + [TARGET]
    fig, axes = plt.subplots(3, 4, figsize=(13, 8))
    for ax, c in zip(axes.flat, cols):
        bins = df[c].nunique() if df[c].nunique() <= 5 else 20
        ax.hist(df[c], bins=bins, color=BLUE, edgecolor=SURFACE, linewidth=1.2)
        ax.set_title(f"{c}  (skew {df[c].skew():+.2f})")
        ax.set_ylabel("patients" if ax in axes[:, 0] else "")
    for ax in list(axes.flat)[len(cols):]:
        ax.set_visible(False)
    fig.suptitle("Distributions of every variable", x=0.01, ha="left",
                 fontsize=13, fontweight="bold")
    fig.tight_layout()
    save(fig, "01_distributions.png")


def plot_target(df: pd.DataFrame) -> None:
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.hist(df[TARGET], bins=25, color=BLUE, edgecolor=SURFACE, linewidth=1.2)
    mean, med = df[TARGET].mean(), df[TARGET].median()
    ax.axvline(mean, color=INK, lw=1.4)
    ax.axvline(med, color=ORANGE, lw=1.4, ls="--")
    ax.text(mean + 2, ax.get_ylim()[1] * 0.95, f"mean {mean:.0f}", color=INK, va="top")
    ax.text(med - 2, ax.get_ylim()[1] * 0.85, f"median {med:.0f}", color=INK2,
            va="top", ha="right")
    ax.set_title("Disease progression one year after baseline")
    ax.set_xlabel("progression score (higher = worse)")
    ax.set_ylabel("patients")
    save(fig, "02_target_distribution.png")


# --------------------------------------------------------------------------
# 4. Group comparisons
# --------------------------------------------------------------------------
def group_analysis(df: pd.DataFrame) -> dict:
    d = df.copy()
    d["bmi_group"] = pd.cut(d["bmi"], [0, 25, 30, 100], right=False,
                            labels=["BMI <25", "25-30", "BMI 30+"])
    d["age_group"] = pd.cut(d["age"], [0, 30, 40, 50, 60, 100], right=False,
                            labels=["<30", "30s", "40s", "50s", "60+"])
    d["sex_group"] = d["sex"].map({1.0: "sex = 1", 2.0: "sex = 2"})

    tables, tests = {}, {}
    for g in ("sex_group", "bmi_group", "age_group"):
        t = (d.groupby(g, observed=True)[TARGET]
             .agg(["count", "mean", "median", "std"]).round(1))
        tables[g] = t
        t.to_csv(OUT_DIR / f"03_progression_by_{g}.csv")

    a, b = (d.loc[d.sex == s, TARGET] for s in (1.0, 2.0))
    tests["sex_welch_t_p"] = float(stats.ttest_ind(a, b, equal_var=False).pvalue)
    for g in ("bmi_group", "age_group"):
        samples = [x[TARGET].values for _, x in d.groupby(g, observed=True)]
        tests[f"{g}_anova_p"] = float(stats.f_oneway(*samples).pvalue)
        tests[f"{g}_kruskal_p"] = float(stats.kruskal(*samples).pvalue)

    fig, axes = plt.subplots(1, 3, figsize=(13, 4.2), sharey=True)
    for ax, g, title in zip(axes, ("sex_group", "bmi_group", "age_group"),
                            ("By sex (coded 1/2)", "By BMI group", "By age group")):
        groups = [x[TARGET].values for _, x in d.groupby(g, observed=True)]
        labels = [str(k) for k, _ in d.groupby(g, observed=True)]
        bp = ax.boxplot(groups, tick_labels=labels, patch_artist=True, widths=0.55,
                        medianprops={"color": INK, "linewidth": 1.6},
                        whiskerprops={"color": INK2}, capprops={"color": INK2},
                        flierprops={"markerfacecolor": INK2, "markeredgecolor": SURFACE,
                                    "markersize": 5})
        for patch in bp["boxes"]:
            patch.set(facecolor=BLUE, alpha=0.75, edgecolor=SURFACE, linewidth=1.5)
        ax.set_title(title)
    axes[0].set_ylabel("progression score")
    fig.suptitle("Progression across patient groups", x=0.01, ha="left",
                 fontsize=13, fontweight="bold")
    fig.tight_layout()
    save(fig, "03_target_by_group.png")
    return {"tables": {k: v.to_dict("index") for k, v in tables.items()}, "tests": tests}


# --------------------------------------------------------------------------
# 5. Correlations
# --------------------------------------------------------------------------
def correlations(df: pd.DataFrame) -> pd.DataFrame:
    cols = FEATURES + [TARGET]
    pearson, spearman = df[cols].corr(), df[cols].corr(method="spearman")
    pearson.round(3).to_csv(OUT_DIR / "04_correlation_pearson.csv")
    spearman.round(3).to_csv(OUT_DIR / "04_correlation_spearman.csv")

    rows = []
    for c in FEATURES:
        r, p = stats.pearsonr(df[c], df[TARGET])
        rho, p_s = stats.spearmanr(df[c], df[TARGET])
        rows.append({"feature": c, "pearson_r": r, "pearson_p": p,
                     "spearman_rho": rho, "spearman_p": p_s})
    tc = (pd.DataFrame(rows).set_index("feature")
          .sort_values("pearson_r", key=np.abs, ascending=False))
    tc.round(4).to_csv(OUT_DIR / "04_target_correlations.csv")

    # Heatmap: orange (negative) - neutral gray - blue (positive)
    cmap = LinearSegmentedColormap.from_list("div", [ORANGE, "#e8e7e3", BLUE])
    mask = np.triu(np.ones_like(pearson, dtype=bool), k=1)
    data = np.ma.array(pearson.values, mask=mask)
    fig, ax = plt.subplots(figsize=(9.2, 7.6))
    im = ax.imshow(data, cmap=cmap, vmin=-1, vmax=1)
    ax.grid(False)
    ax.set_xticks(range(len(cols)), cols, rotation=40, ha="right")
    ax.set_yticks(range(len(cols)), cols)
    for i in range(len(cols)):
        for j in range(i + 1):
            v = pearson.values[i, j]
            ax.text(j, i, f"{v:.2f}", ha="center", va="center", fontsize=8,
                    color=SURFACE if abs(v) > 0.6 else INK)
    for s in ax.spines.values():
        s.set_visible(False)
    cb = fig.colorbar(im, ax=ax, shrink=0.75)
    cb.set_label("Pearson r")
    ax.set_title("Correlation matrix (Pearson)")
    save(fig, "04_correlation_heatmap.png")

    # Correlation with target, sorted
    t = tc["pearson_r"].sort_values()
    fig, ax = plt.subplots(figsize=(7.5, 4.6))
    bars = ax.barh(t.index, t.values, height=0.6,
                   color=[BLUE if v > 0 else ORANGE for v in t.values],
                   edgecolor=SURFACE)
    for bar, v in zip(bars, t.values):
        ax.text(v + (0.012 if v > 0 else -0.012), bar.get_y() + bar.get_height() / 2,
                f"{v:+.2f}", va="center", ha="left" if v > 0 else "right", color=INK)
    ax.axvline(0, color=INK2, lw=0.8)
    ax.grid(axis="y", visible=False)
    ax.set_xlim(-0.55, 0.75)
    ax.set_xlabel("Pearson r with progression")
    ax.set_title("Which variables move with disease progression?")
    ax.legend(handles=[Patch(color=BLUE, label="positive"),
                       Patch(color=ORANGE, label="negative")],
              loc="lower right", frameon=False)
    save(fig, "05_target_correlations.png")

    # Scatter small multiples for the 4 strongest
    top = tc.index[:4]
    fig, axes = plt.subplots(1, 4, figsize=(14, 3.7), sharey=True)
    for ax, c in zip(axes, top):
        ax.scatter(df[c], df[TARGET], s=30, color=BLUE, alpha=0.55,
                   edgecolor=SURFACE, linewidth=0.6)
        m, b = np.polyfit(df[c], df[TARGET], 1)
        xs = np.linspace(df[c].min(), df[c].max(), 50)
        ax.plot(xs, m * xs + b, color=ORANGE, lw=2)
        ax.set_title(f"{c}  (r = {tc.loc[c, 'pearson_r']:+.2f})")
        ax.set_xlabel(c)
    axes[0].set_ylabel("progression score")
    fig.suptitle("Strongest relationships with progression", x=0.01, ha="left",
                 fontsize=13, fontweight="bold")
    fig.tight_layout()
    save(fig, "06_top_scatter.png")
    return tc


# --------------------------------------------------------------------------
# 6. Key influencing factors
# --------------------------------------------------------------------------
def vif(X: pd.DataFrame) -> pd.Series:
    out = {}
    for c in X.columns:
        A = np.column_stack([np.ones(len(X)), X.drop(columns=c).values])
        b, *_ = np.linalg.lstsq(A, X[c].values, rcond=None)
        res = X[c].values - A @ b
        r2 = 1 - (res @ res) / ((X[c] - X[c].mean()) ** 2).sum()
        out[c] = 1 / (1 - r2)
    return pd.Series(out)


def key_factors(df: pd.DataFrame, tc: pd.DataFrame) -> dict:
    X, y = df[FEATURES], df[TARGET]

    # (a) standardised OLS: coefficients comparable across variables
    Z = (X - X.mean()) / X.std(ddof=0)
    yz = (y - y.mean()) / y.std(ddof=0)
    A = np.column_stack([np.ones(len(Z)), Z.values])
    beta, *_ = np.linalg.lstsq(A, yz.values, rcond=None)
    resid = yz.values - A @ beta
    dof = len(yz) - A.shape[1]
    se = np.sqrt(np.diag(resid @ resid / dof * np.linalg.inv(A.T @ A)))
    t = beta / se
    tcrit = stats.t.ppf(0.975, dof)
    ols = pd.DataFrame({
        "std_beta": beta[1:], "ci_low": (beta - tcrit * se)[1:],
        "ci_high": (beta + tcrit * se)[1:],
        "p_value": (2 * stats.t.sf(np.abs(t), dof))[1:],
    }, index=FEATURES)
    ols_r2 = 1 - (resid @ resid) / ((yz - yz.mean()) ** 2).sum()

    # (b) random forest + permutation importance on held-out data
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.25, random_state=SEED)
    rf = RandomForestRegressor(n_estimators=400, min_samples_leaf=5,
                               random_state=SEED, n_jobs=-1).fit(X_tr, y_tr)
    pi = permutation_importance(rf, X_te, y_te, n_repeats=30,
                                random_state=SEED, n_jobs=-1)
    perm = pd.DataFrame({"importance": pi.importances_mean,
                         "std": pi.importances_std}, index=FEATURES)

    cv = KFold(5, shuffle=True, random_state=SEED)
    lin_cv = cross_val_score(LinearRegression(), X, y, cv=cv, scoring="r2")
    rf_cv = cross_val_score(RandomForestRegressor(
        n_estimators=300, min_samples_leaf=5, random_state=SEED, n_jobs=-1),
        X, y, cv=cv, scoring="r2")

    # (c) multicollinearity
    v = vif(X)

    ranking = pd.DataFrame({
        "abs_pearson_r": tc["pearson_r"].abs(),
        "std_beta": ols["std_beta"], "ols_p": ols["p_value"],
        "perm_importance": perm["importance"], "vif": v,
    }).sort_values("perm_importance", ascending=False)
    ranking.round(4).to_csv(OUT_DIR / "05_key_factors.csv")
    ols.round(4).to_csv(OUT_DIR / "05_standardised_ols.csv")

    # Figure: permutation importance
    p = perm.sort_values("importance")
    fig, ax = plt.subplots(figsize=(7.5, 4.6))
    ax.barh(p.index, p["importance"], xerr=p["std"], height=0.6, color=BLUE,
            edgecolor=SURFACE, error_kw={"ecolor": INK2, "elinewidth": 1,
                                         "capsize": 3})
    ax.grid(axis="y", visible=False)
    ax.set_xlabel("drop in held-out R² when the variable is shuffled")
    ax.set_title("Key influencing factors (random forest permutation importance)")
    save(fig, "07_feature_importance.png")

    # Figure: standardised coefficients with CI
    o = ols.sort_values("std_beta")
    fig, ax = plt.subplots(figsize=(7.5, 4.6))
    ypos = np.arange(len(o))
    colors = [BLUE if b > 0 else ORANGE for b in o["std_beta"]]
    ax.hlines(ypos, o["ci_low"], o["ci_high"], color=INK2, lw=1.6)
    ax.scatter(o["std_beta"], ypos, s=60, color=colors, edgecolor=SURFACE,
               linewidth=1.5, zorder=3)
    ax.axvline(0, color=INK2, lw=0.8)
    ax.set_yticks(ypos, o.index)
    ax.grid(axis="y", visible=False)
    ax.set_xlabel("standardised coefficient (95% CI), all variables held constant")
    ax.set_title("Effect of each variable after controlling for the others")
    ax.legend(handles=[Patch(color=BLUE, label="raises progression"),
                       Patch(color=ORANGE, label="lowers progression")],
              loc="lower right", frameon=False)
    save(fig, "08_standardised_coefficients.png")

    return {
        "ols_r2": float(ols_r2),
        "rf_test_r2": float(rf.score(X_te, y_te)),
        "linear_cv_r2_mean": float(lin_cv.mean()), "linear_cv_r2_std": float(lin_cv.std()),
        "rf_cv_r2_mean": float(rf_cv.mean()), "rf_cv_r2_std": float(rf_cv.std()),
        "ranking": ranking.round(4).to_dict("index"),
    }


def main() -> None:
    style()
    df = load()
    results: dict = {"overview": inspect(df)}
    results["summary"] = summarise(df).to_dict("index")
    plot_distributions(df)
    plot_target(df)
    results["groups"] = group_analysis(df)
    tc = correlations(df)
    results["target_correlations"] = tc.round(4).to_dict("index")
    results["key_factors"] = key_factors(df, tc)
    (OUT_DIR / "results.json").write_text(json.dumps(results, indent=2, default=float))

    pd.set_option("display.width", 160)
    print("OVERVIEW", results["overview"])
    print("\nSUMMARY\n", summarise(df)[["mean", "std", "min", "max", "skew",
                                       "iqr_outliers", "shapiro_p"]])
    print("\nGROUP TABLES / TESTS")
    for k, v in results["groups"]["tables"].items():
        print(k, v)
    print(results["groups"]["tests"])
    print("\nTARGET CORRELATIONS\n", tc.round(3))
    kf = results["key_factors"]
    print("\nMODEL FIT", {k: round(v, 3) for k, v in kf.items() if k != "ranking"})
    print("\nKEY FACTORS\n", pd.DataFrame(kf["ranking"]).T.round(3))


if __name__ == "__main__":
    main()

# Exploratory Data Analysis with pandas: What Drives Diabetes Progression?

A hands-on EDA project that practises the three skills in the brief:

| Goal | Where it happens |
|---|---|
| Statistical summaries and visualisations | `describe()`, skew/kurtosis, IQR outliers, Shapiro-Wilk; distributions, box plots, scatter plots |
| Correlations and key influencing factors | Pearson + Spearman matrices; standardised regression; random-forest permutation importance; VIF |
| Structured insights report | [`REPORT.md`](REPORT.md) |

## Quick start

```bash
pip install -r requirements.txt
python eda.py
```

The script is self-contained: the dataset ships with scikit-learn, so no download is needed. It writes everything below.

## Project layout

```
eda.py            the full analysis, in six numbered sections
REPORT.md         the structured insights report (start here)
data/             diabetes.csv (442 patients)
figures/          8 charts (PNG)
outputs/          summary tables (CSV), results.json, run_log.txt
requirements.txt
```

## Analysis steps

1. **Load and inspect** the data: shape, types, missing values, duplicates.
2. **Summarise** every variable with descriptive statistics, skewness, outlier counts and normality tests.
3. **Visualise distributions** of all variables and the target.
4. **Compare groups** (BMI band, age band, sex) with ANOVA, Kruskal-Wallis and Welch t-tests.
5. **Correlate**: Pearson and Spearman matrices, plus each variable against the target.
6. **Find key factors** with three complementary views, and check multicollinearity (VIF) so the results are not misread.

## Exercises to extend it

- Add residual diagnostics for the linear model (residual vs fitted plot, Q-Q plot).
- Try the larger Wine or California Housing datasets from scikit-learn and reuse the same pipeline.
- Turn `eda.py` into a Jupyter notebook, one cell per section.
- Replace the BMI/age bands with different cut points and check whether the conclusions hold.
